import React from 'react';
import './App.css';
import form from './forms.js'

// const nick = prompt('Please Enter Your Name')


class Display extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      messages: [],
      nick : '',
    }
  }
  
 componentDidMount(){
  fetch('../messages')
    .then(response => response.json())
    .then(data => {
      console.log(data)
      this.setState({messages:data})
      })
 }

function msgField(){
  form.state.value
 }

 dateStamp(date){
   let newDate = new Date(date)
  let h = newDate.getHours();
  let min = newDate.getMinutes();
  let d = newDate.getDate();
  let m = newDate.getMonth();
  let y = newDate.getFullYear()
  return m + "-" +d + "-" + y + " " + h +":"+ min
 }

  render() {
    
    return (
    <div>
      {this.state.messages.map((msg, index)=>{
        return(<li key={index}>
          <p>{msg.nick}</p>
          <p>{msg.text}</p>
          <p>{this.dateStamp(msg.date)}</p>
     </li> )})}
    </div>
    );
  }


}
export default Display;
